"""DPS-SAM Auto-grid prompt (Dict1), extracted without algorithm changes."""
import torch
import numpy as np
from typing import Any, Dict, List
from torchvision.ops.boxes import batched_nms
from SAM_Med2D.segment_anything.automatic_mask_generator import SamAutomaticMaskGenerator
from SAM_Med2D.segment_anything.utils.amg import (
    MaskData, area_from_rle, batched_mask_to_box, box_xyxy_to_xywh,
    calculate_stability_score, coco_encode_rle, is_box_near_crop_edge,
    mask_to_rle_pytorch, remove_small_regions, rle_to_mask,
)

class LogitsMaskGenerator(SamAutomaticMaskGenerator):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # 如果你想把所有批次的 logits 存到一个大列表里，可以在这里初始化
        # self.all_logits = [] 
    @torch.no_grad()
    def generate(self, image: np.ndarray) -> List[Dict[str, Any]]:
        """
        重写 generate 函数以在输出中包含 logits。
        """

        # 1. 生成 Mask 数据 (这里假设你的 _generate_masks 已经返回了包含 logits 的 mask_data)
        mask_data = self._generate_masks(image)

        # 2. 过滤小的非连接区域 (原逻辑)
        if self.min_mask_region_area > 0:
            mask_data = self.postprocess_small_regions(
                mask_data,
                self.min_mask_region_area,
                max(self.box_nms_thresh, self.crop_nms_thresh),
            )

        # 3. 编码 Mask (原逻辑)
        if self.output_mode == "coco_rle":
            mask_data["segmentations"] = [coco_encode_rle(rle) for rle in mask_data["rles"]]
        elif self.output_mode == "binary_mask":
            mask_data["segmentations"] = [rle_to_mask(rle) for rle in mask_data["rles"]]
        else:
            mask_data["segmentations"] = mask_data["rles"]

        # 4. 写入 Mask 记录 (这里是唯一需要修改的地方)
        curr_anns = []
        for idx in range(len(mask_data["segmentations"])):
            ann = {
                "segmentation": mask_data["segmentations"][idx],
                "area": area_from_rle(mask_data["rles"][idx]),
                "bbox": box_xyxy_to_xywh(mask_data["boxes"][idx]).tolist(),
                "predicted_iou": mask_data["iou_preds"][idx].item(),
                "point_coords": [mask_data["points"][idx].tolist()],
                "stability_score": mask_data["stability_score"][idx].item(),
                "crop_box": box_xyxy_to_xywh(mask_data["crop_boxes"][idx]).tolist(),
                
                # --- 新增部分 ---
                # 注意：mask_data 中的数据通常在 GPU 上，且是 Tensor
                # 为了方便后续处理，通常转为 numpy 并移到 CPU
                "logits": mask_data["logits"][idx]
            }
            curr_anns.append(ann)

        return curr_anns
    def _process_batch(
        self,
        points: np.ndarray,
        im_size: tuple,
        crop_box: list,
        orig_size: tuple,
    ) -> MaskData:
        """
        重写 _process_batch 以保留 logits。
        """
        orig_h, orig_w = orig_size

        # 1. 运行预测 (Run model on this batch)
        transformed_points = self.predictor.transform.apply_coords(points, im_size)
        in_points = torch.as_tensor(transformed_points, device=self.predictor.device)
        in_labels = torch.ones(in_points.shape[0], dtype=torch.int, device=self.predictor.device)

        # 这里的 predict_torch 返回 masks, iou_predictions, low_res_masks
        masks, iou_preds, low_res_masks = self.predictor.predict_torch(
            point_coords=in_points[:, None, :],
            point_labels=in_labels[:, None],
            multimask_output=True,
            return_logits=True,  # <--- 关键点：必须设置为 True 以获取 Logits
        )

        # 2. 序列化处理 (Serialize predictions and store in MaskData)
        data = MaskData(
            masks=masks.flatten(0, 1),
            iou_preds=iou_preds.flatten(0, 1),
            points=torch.as_tensor(points.repeat(masks.shape[1], axis=0), device=masks.device),
        )
        # --- 新增部分：保存 Logits ---
        # 此时 data.masks 已经是 logits 了，因为上面 return_logits=True
        # 为了避免混淆，我们显式地把 logits 存一份到 data 对象里
        # 注意：为了节省显存，你可能希望把它转回 CPU 或者只保留需要的
        data["logits"] = low_res_masks.flatten(0, 1)
        del masks
        del low_res_masks


       
        
        # 3. 过滤 (Filter by IoU)
        if self.pred_iou_thresh > 0.0:
            keep_mask = data["iou_preds"] > self.pred_iou_thresh
            data.filter(keep_mask)

        # 4. 稳定性计算 (Calculate stability score)
        # 注意：calculate_stability_score 需要的是 mask 的阈值化结果，
        # 但因为我们上面开启了 return_logits=True，现在的 data.masks 是 logits (浮点数)。
        # 所以计算稳定性时，我们需要临时把 logits 转成 mask (大于阈值)
        data["stability_score"] = calculate_stability_score(
            data["masks"], self.predictor.model.mask_threshold, self.stability_score_offset
        )
        
        if self.stability_score_thresh > 0.0:
            keep_mask = data["stability_score"] >= self.stability_score_thresh
            data.filter(keep_mask)

        # 5. 阈值化 masks (Threshold masks)
        # 在这一步之前，data.masks 一直是 logits。
        # 标准流程在这里会把 logits 变成布尔值 mask。
        # 我们在覆盖它之前，确保上面的 data["logits"] 已经保存好了。
        data["masks"] = data["masks"] > self.predictor.model.mask_threshold

        # 6. 尺寸恢复与裁剪 (Post-processing)
        data["boxes"] = batched_mask_to_box(data["masks"])
        
        # 过滤掉接触到裁剪框边缘的 mask (Filter boxes that touch crop boundaries)
        data.filter(
            ~is_box_near_crop_edge(data["boxes"], crop_box, [0, 0, orig_w, orig_h])
        )

        # 压缩 masks (Compress to RLE)
        data["rles"] = mask_to_rle_pytorch(data["masks"])
        
        # 此时，data 对象里除了原有的 masks, rles, boxes 等，还多了一个 "logits" 键
        # 删除显存中大的 dense masks 以节省空间，只保留 RLE 和 logits
        del data["masks"]
        if "logits" in data._stats:
            # .detach() 确保切断梯度计算图（虽然 inference 模式下通常没有，但为了保险）
            # .half() 将 float32 转为 float16，内存占用减半
            # .cpu() 转移到内存
            data["logits"] = data["logits"].detach().half().cpu()
        return data
            
    def postprocess_small_regions(
        self, mask_data: MaskData, min_area: int, nms_thresh: float
    ) -> MaskData:
        """
        这是原版逻辑的完整复刻。
        它会执行：去噪点 -> 填孔洞 -> 重新计算Box -> 基于稳定性的NMS。
        
        关键点：
        只要 mask_data 中包含 'logits' 字段，最后的 filter() 会自动同步处理它。
        """
        
        # 如果没有 RLE 数据，直接返回（通常不会发生）
        if "rles" not in mask_data._stats:
             # 如果还没转 RLE，先处理一下，保证逻辑兼容
             return super().postprocess_small_regions(mask_data, min_area, nms_thresh)

        if len(mask_data["rles"]) == 0:
            return mask_data

        # 1. 过滤小的离散区域和孔洞 (Filter small disconnected regions and holes)
        new_masks = []
        scores = []
        
        # 遍历每一个 Mask
        for rle in mask_data["rles"]:
            mask = rle_to_mask(rle)

            # 填补孔洞
            mask, changed = remove_small_regions(mask, min_area, mode="holes")
            unchanged = not changed
            
            # 去除孤岛
            mask, changed = remove_small_regions(mask, min_area, mode="islands")
            unchanged = unchanged and not changed

            new_masks.append(torch.as_tensor(mask).unsqueeze(0))
            
            # 如果 Mask 被修改过（去噪或填孔），得分为 0；没变过得分为 1。
            # 这样 NMS 会优先保留没有经过“修补”的原始 Mask。
            scores.append(float(unchanged))

        # 2. 重新计算 Boxes 并移除新的重复项
        masks = torch.cat(new_masks, dim=0)
        boxes = batched_mask_to_box(masks)
        
        # 执行 NMS
        # 注意：这里使用的是 scores (即是否被修改过)，而不是 iou_preds
        keep_by_nms = batched_nms(
            boxes.float(),
            torch.as_tensor(scores),
            torch.zeros_like(boxes[:, 0]),  # categories (全0表示同类)
            iou_threshold=nms_thresh,
        )

        # 3. 只对保留下来的、且发生过变化的 Mask 更新 RLE 和 Box
        for i_mask in keep_by_nms:
            if scores[i_mask] == 0.0:
                # 只有当 mask 被 remove_small_regions 修改过，我们才更新它的 RLE
                mask_torch = masks[i_mask].unsqueeze(0)
                mask_data["rles"][i_mask] = mask_to_rle_pytorch(mask_torch)[0]
                mask_data["boxes"][i_mask] = boxes[i_mask] 
                
                # 【注意】：这里我们更新了 Mask (rles) 和 Box，但没有更新 Logits。
                # Logits 依然是原始的。这就是所谓的“不一致性”。
                # 但通常这不会导致程序报错。

        # 4. 过滤数据 (Filter data)
        # MaskData 的 filter 方法会遍历内部所有字段（包括你加的 logits）
        # 并根据 keep_by_nms 进行切片。
        mask_data.filter(keep_by_nms)
        return mask_data

def semisam_branch(args,volume_branch,output_unlabeled,unlabeled_tag,mask_generator,device ="cuda"):
# volume_branch: 输入的数据
# mask_gt: 输入的mask,如果有
#b,c,h,w = volume_branch.shap
### 运用auto_grid的方式得到所有存在的mask，注意过滤参数的选择
### image shape :in BHWC uint8 format. The generate function receive HWC format

    B,C,H,W = output_unlabeled.shape
    # masks = torch.argmax(output_unlabeled, dim=1)  # (B, H, W)
    # masks_one_hot = F.one_hot(unlabeled_tag, num_classes=C).permute(0, 3, 1, 2).float()  #
    # image_merged,region_boxes,resized_patches = extract_and_merge_regions(volume_branch,masks_one_hot,scale=2,output_size=(256, 256))
    # resized_patches_unit8 = float32_to_uint8(resized_patches.cpu().numpy())
    cur_anns = [[] for i in range(B)]
    for i in range(B):
        with torch.no_grad():
            mask_j = mask_generator.generate(volume_branch[i].repeat(3,1,1).permute(1,2,0).cpu().numpy())    ### 也就是说这里的mask_j本身就是logits。
            #mask_i = mask_generator.generate(resized_patches_unit8[i].repeat(3, axis=0).transpose(1,2,0))
        for m in range(len(mask_j)):
            a = 0
            #original_mask_i = restore_prediction_to_original(mask_i[m]['segmentation'],region_boxes[i],original_size=(256,256))
            cur_anns[i].append({'logits':torch.from_numpy(mask_j[m]['logits']),'iou':mask_j[m]['predicted_iou'],'masks':torch.from_numpy(mask_j[m]['segmentation'])})
    return cur_anns  ### B,NUM_MASK,h,w
