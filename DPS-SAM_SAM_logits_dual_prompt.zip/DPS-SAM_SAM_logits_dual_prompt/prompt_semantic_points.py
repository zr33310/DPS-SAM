"""DPS-SAM semantic-mask guided point prompt (Dict2), extracted without algorithm changes."""
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

class MedSAM_tune_predict(nn.Module):
    def __init__(self, 
                image_encoder, 
                mask_decoder,
                prompt_encoder,
                freeze_image_encoder=False,
                ):
        super().__init__()
        self.image_encoder = image_encoder
        self.mask_decoder = mask_decoder
        self.prompt_encoder = prompt_encoder

        # freeze prompt encoder
        for param in self.prompt_encoder.parameters():
            param.requires_grad = False
        
        self.freeze_image_encoder = freeze_image_encoder
        if self.freeze_image_encoder:
            for param in self.image_encoder.parameters():
                param.requires_grad = False


    def forward(self, image, point_prompt):
        # do not compute gradients for pretrained img encoder and prompt encoder
        with torch.no_grad():
            image_embedding = self.image_encoder(image) # (B, 256, 64, 64)
            # not need to convert box to 1024x1024 grid
            # bbox is already in 1024x1024
            sparse_embeddings, dense_embeddings = self.prompt_encoder(
                points=point_prompt,
                boxes=None,
                masks=None,
            )
            low_res_masks, iou_predictions = self.mask_decoder(
                image_embeddings=image_embedding, # (B, 256, 64, 64)
                image_pe=self.prompt_encoder.get_dense_pe(), # (1, 256, 64, 64)
                sparse_prompt_embeddings=sparse_embeddings, # (B, 2, 256)
                dense_prompt_embeddings=dense_embeddings, # (B, 256, 64, 64)
                multimask_output=False,
            ) # (B, 1, 64, 64)
        return low_res_masks,iou_predictions

def convert_mask_to_target_general(mask, background_val=0,num=3):
    """
    将 [H, W] 的语义分割 mask 转换为 [C, H, W] 的目标格式：
    - mask 中 background_val 被视为背景，其余唯一值视为前景类别。
    - 对于每个前景类别 c：
        - mask==c 的位置为 1
        - mask==其他前景类 的位置为 -1
        - mask==背景 的位置为 0
    
    返回：
        target: [C, H, W] int8 tensor
        classes: [C] tensor，对应 target 每个通道的类别值
    """
    assert isinstance(mask, np.ndarray), "mask 必须为 numpy.ndarray 类型"
    H, W = mask.shape

    classes = np.arange(1, num + 1).astype(mask.dtype)
    C = len(classes)

    # 创建广播结构: [C, 1, 1] 与 [1, H, W] 比较 -> [C, H, W]
    mask_exp = np.expand_dims(mask, axis=0)         # [1, H, W]
    class_exp = classes[:, None, None]              # [C, 1, 1]

    is_pos = (mask_exp == class_exp).astype(np.int8)
    is_neg = ((mask_exp != class_exp) & (mask_exp != background_val)).astype(np.int8)

    target = is_pos * 1 + is_neg * (-1)             # [C, H, W]
    return target, classes

def sample_points_from_mask(mask, m, seed=None,device='cpu'):
    """
    从一个 mask 中采样 m 个值为 1 的点（正类）
    
    参数：
        mask: [H, W] 的 numpy array 或 torch tensor，值中包含 1、-1、0 等
        m: 要采样的正样本数量（值为 1 的点）
        seed: 随机种子（可选）

    返回：
        如果有足够的正样本区域：
            samples: [m, 2] 的 numpy 数组，每行是 (x, y)
            labels: [m] 的 numpy 数组，全部为 1
        如果没有正样本区域：
            None, None
    """
    if seed is not None:
        np.random.seed(seed)

    if not isinstance(mask, np.ndarray):
        mask = mask.cpu().numpy()  # 支持 torch tensor 输入

    # 获取值为 1 的坐标
    pos_coords = np.argwhere(mask == 1)   # shape: [N_pos, 2]
    
    # 如果没有正样本区域，返回 None
    if len(pos_coords) == 0:
        return None
    
    # 从正样本中采样 m 个点
    pos_sampled = pos_coords[np.random.choice(len(pos_coords), m, replace=(len(pos_coords) < m))]
    
    # 转换坐标从 (y, x) 到 (x, y)
    samples = pos_sampled[:, [1, 0]]
    
    # 生成标签，全部为 1（正样本）
    labels = np.ones(m, dtype=np.int64)

    samples = torch.from_numpy(samples).unsqueeze(0).to(device)
    labels = torch.from_numpy(labels).unsqueeze(0).to(device)
    return (samples, labels)

def semisam_branch_ambiguity_logits(generalist,volume_branch,output_softmax,single_point_SAM_predictor,unlabeled_tag,args,mask_number=8,device='cuda'):
    output_mask = unlabeled_tag
    output_mask_np = output_mask.cpu().numpy()
    #sam_predictor = SamPredictor_original(sam_module_tune)

    B,C,H,W =  output_softmax.shape
    #images = float32_to_uint8(volume_branch.cpu().numpy())
    images = volume_branch
    mask_ambuguity = [[] for i in range(B)]
    for b in range(B):
        image = images[b].unsqueeze(0)
        # mask_C,class_num = convert_single_logits_to_target_no_background(output_softmax[b],background_index=0)
        mask_C,class_num = convert_mask_to_target_general(output_mask_np[b],background_val=0,num=C-1)
        #sam_predictor.set_image(image)
        for i in range(C-1):   ### 去掉背景
            mask_c = mask_C[i]
            #mask_input = np.expand_dims((mask_c == 1), axis=0) if generalist=="sam-original" else None
            for j in range(mask_number):
                point_prompt = sample_points_from_mask(mask_c,10,seed=1337,device=device)
                # input_points = torch.from_numpy(input_points).unsqueeze(0).to(device)
                # input_labels = torch.from_numpy(input_labels).unsqueeze(0).to(device)
                # masks, scores, logits = sam_predictor.predict(
                #                                             point_coords=input_points,
                #                                             point_labels=input_labels,
                #                                             mask_input = mask_input,
                #                                             multimask_output=True,
                #
                #                                          )
                with torch.no_grad():
                    logits,scores = single_point_SAM_predictor(image,point_prompt)
                    logits = F.interpolate(logits, size=(H,W), mode='bilinear', align_corners=False)
                    #logits = F.sigmoid(logits)
                mask_ambuguity[b].append({'score':scores.cpu(),'logits':logits})
    return mask_ambuguity   ### B, C-1 * mask_number, [mask 有3个]
