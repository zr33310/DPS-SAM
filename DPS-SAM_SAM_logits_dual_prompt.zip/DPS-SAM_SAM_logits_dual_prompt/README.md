# DPS-SAM：SAM logits 与双重 prompt 代码

仅包含三部分代码：

1. `SAM_Med2D/segment_anything/`：项目实际使用的 SAM-Med2D 本体、构建器、预测器及必要依赖。
2. `prompt_auto_grid.py`：Auto-grid（Dict1），包含保留 logits 的 `LogitsMaskGenerator` 和批处理入口 `semisam_branch`。
3. `prompt_semantic_points.py`：语义掩膜引导点提示（Dict2），包含 `MedSAM_tune_predict`、掩膜转换、正点采样与 `semisam_branch_ambiguity_logits`。

源码来自 `dual_prompt_adaptive_weight_code/`。SAM 文件原样复制；两条 prompt 从 `SAM_utils/sam_dict.py` 提取，点提示预测封装从 `train_MT_SAM_Dict1&Dict2_only1consistency.py` 提取。仅拆分模块和整理 import，未改算法。未包含训练、学生/教师网络、候选匹配、损失、权重计算、数据集及模型权重。

## logits 接口

- 构建器：`from SAM_Med2D.segment_anything import sam_model_registry`。
  `sam_model_registry['vit_b'](args)`，args 需要 `image_size`、`sam_checkpoint`、`encoder_adapter`。
- 实际注册的 `Sam` 位于 `modeling/sam_model.py`，其 `forward` 输出字典的 `masks` 是插值后的原始 logits，`low_res_logits` 是低分辨率原始 logits，另有 `iou_predictions`。
- `SamPredictor.predict/predict_torch` 需传 `return_logits=True`，返回 `(logits, iou_predictions, low_res_logits)`。
- `LogitsMaskGenerator.generate(image)` 返回候选列表，其中 `logits` 是低分辨率 logits（CPU float16），`segmentation` 是另外保留的二值掩膜。直接使用基础 `SamAutomaticMaskGenerator` 不会在候选字典中返回 logits。
- `MedSAM_tune_predict(image, point_prompt)` 返回 `(low_res_logits, iou_predictions)`，未进行 sigmoid 或阈值化。Dict2 批处理入口将 logits 插值到输入图像尺寸。

## 保留的原始接口行为

- Dict1 的 `semisam_branch` 接收单通道 BCHW 图像，并重复为三通道；输出尺寸从 `output_unlabeled.shape` 获取。
- Dict2 接收三通道 BCHW 图像；当前原函数实际从 `unlabeled_tag` 构建提示掩膜，`output_softmax` 仅用于获取形状，没有自动从其预测结果生成提示。若以预测引导提示，应由调用方明确传入预测类别掩膜。这里保留原始行为。
- 原点采样调用每次固定 `seed=1337`，多组点可能重复；未更改随机策略。
- Auto-grid 原实现保留低分辨率 logits；裁剪候选的 logits 没有恢复到全图坐标，使用时需结合 `crop_box` 解释。此包为源码提取，不包含后续实验目录中的对齐修订。

## 依赖与使用

需要已有兼容的 `torch`、`torchvision`、`numpy`、`Pillow` 环境。小区域后处理可选依赖 `opencv-python`，COCO RLE 输出可选依赖 `pycocotools`。权重需另行提供。

从解压目录导入：

```python
from SAM_Med2D.segment_anything import sam_model_registry, SamPredictor
from prompt_auto_grid import LogitsMaskGenerator, semisam_branch
from prompt_semantic_points import MedSAM_tune_predict, semisam_branch_ambiguity_logits
```

本体和 prompt 的许可证随包保留。打包时进行了 Python 语法与 ZIP 完整性检查；未加载模型权重执行真实图像推理。
